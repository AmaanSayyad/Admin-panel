import React from 'react';

function Error(props) {
	return <p className='help is-danger'>{props.error}</p>;
}

export default Error;
