export const NUMBER_OF_PRODUCTS_ON_PAGE = 9;
export const NUMBER_OF_PAGINATION_ELEMENTS = 3;
export const PAGINATION_STYLE = 'rounded';
export const PAGINATION_SIZE = 'medium';
export const PAGINATION_ALIGNMENT = 'left';
