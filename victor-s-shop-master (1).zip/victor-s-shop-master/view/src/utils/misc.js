export const isEmptyArray = (arr) => arr.length === 0;
