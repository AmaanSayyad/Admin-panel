const UserActionTypes = {
	START_LOADING: 'START_LOADING',
	UPDATE_USER_DATA: 'UPDATE_USER_DATA',
	UPDATE_ERROR: 'UPDATE_ERROR'
};

export default UserActionTypes;
