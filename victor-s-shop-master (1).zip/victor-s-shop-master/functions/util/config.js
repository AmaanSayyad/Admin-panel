module.exports = {
	apiKey: 'AIzaSyBl3_Zllqe8qhN93PaVQzCyeowxq-kruD0',
	authDomain: 'aligo-test.firebaseapp.com',
	databaseURL: 'https://aligo-test.firebaseio.com',
	projectId: 'aligo-test',
	storageBucket: 'aligo-test.appspot.com',
	messagingSenderId: '679717332587',
	appId: '1:679717332587:web:bc75f364e10940a546f32e',
	measurementId: 'G-XWNJ82NYRG'
};
